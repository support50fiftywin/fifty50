module.exports = {
  content: ["./*.html"],
  theme: {
    extend: {
      colors: {
        'brand-accent': '#e11d48',
      },
    },
  },
  plugins: [],
};
